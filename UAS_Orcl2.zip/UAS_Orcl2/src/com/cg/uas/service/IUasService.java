package com.cg.uas.service;


import java.util.List;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.exception.UASException;

public interface IUasService {
	public LoginBean login(String username, String password) throws UASException ;
	
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) throws UASException;
	
	public List<ProgramsOfferedBean> viewAllProgramsOffered() throws UASException;

	public boolean deleteProgramsOffered(String programName) throws UASException;
	
	public ProgramsOfferedBean findByName(String programName) throws UASException;
	
	public int modifyProgram(ProgramsOfferedBean bean) throws UASException;

	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean) throws UASException;

	public List<ProgramsScheduledBean> viewAllProgramsScheduled() throws UASException;

	public boolean deleteProgramsScheduled(int id) throws UASException;

	public List<ProgramsScheduledBean> viewCommenceTime(ProgramsScheduledBean bean) throws UASException;
	
	public List<ProgramsScheduledBean> viewCourse() throws UASException;
	
	public ApplicationBean addApplicant(ApplicationBean application) throws UASException;
	
	public ApplicationBean viewStatus(int id) throws UASException;

	public List<ApplicationBean> getAllApplicants(String scheduledProgramID) throws UASException;

	public String getStatus(String applicantId) throws UASException;

	public String changeStatus(String status,String applicantId) throws UASException;



}
