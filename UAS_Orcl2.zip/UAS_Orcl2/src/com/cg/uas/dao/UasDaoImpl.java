package com.cg.uas.dao;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.exception.UASException;

@Repository
@Transactional
public class UasDaoImpl implements IUasDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public LoginBean login(String username, String password) throws UASException {
	
		try {
			LoginBean bean = entityManager.find(LoginBean.class,username);
			return bean;
		} catch (Exception e) {
		throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	
	}

	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) throws UASException {
		try {
			entityManager.persist(bean);
			ProgramsOfferedBean bean1=entityManager.find(ProgramsOfferedBean.class, bean.getProgramName());
			entityManager.flush();
			return bean1;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	
	}

	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() throws UASException {
		try {
			TypedQuery<ProgramsOfferedBean> query=entityManager.createQuery("FROM ProgramsOfferedBean",ProgramsOfferedBean.class);
			if(query.getResultList()!=null)
				return query.getResultList();
			else{
				List<ProgramsOfferedBean> list=new ArrayList<ProgramsOfferedBean>();
				return list;
			}
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public boolean deleteProgramsOffered(String programName) throws UASException {
		try {
			boolean flag= false;
			ProgramsOfferedBean bean = entityManager.find(ProgramsOfferedBean.class,programName);
			if(bean!=null){
				entityManager.remove(bean);
				
			flag = true;
			}
			else{
				flag = false;
			}
			return flag;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
		
	}

	@Override
	public ProgramsOfferedBean findByName(String programName) throws UASException {
		try {
			ProgramsOfferedBean bean1=entityManager.find(ProgramsOfferedBean.class, programName);
			return bean1;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public int modifyProgram(ProgramsOfferedBean bean) throws UASException {
		
		try {
			Query query=entityManager.createQuery("update ProgramsOfferedBean set description=?,applicantEligibility=?,duration=?,degreeCertificate=? where programName=?");
			query.setParameter(1, bean.getDescription());
			query.setParameter(2, bean.getApplicantEligibility());
			query.setParameter(3, bean.getDuration());
			query.setParameter(4, bean.getDegreeCertificate());
			query.setParameter(5, bean.getProgramName());
			int count= query.executeUpdate();
			return count;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public ProgramsScheduledBean addScheduledPrograms(ProgramsScheduledBean bean) throws UASException {
		try {
			entityManager.persist(bean);
			ProgramsScheduledBean bean1=entityManager.find(ProgramsScheduledBean.class, bean.getScheduledProgramId());
			entityManager.flush();
			return bean1;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public List<ProgramsScheduledBean> viewAllProgramsScheduled() throws UASException {
		try {
			TypedQuery<ProgramsScheduledBean> query=entityManager.createQuery("FROM ProgramsScheduledBean",ProgramsScheduledBean.class);
			if(query.getResultList()!=null)
				return query.getResultList();
			else{
				List<ProgramsScheduledBean> list=new ArrayList<ProgramsScheduledBean>();
				return list;
			}
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public boolean deleteProgramsScheduled(int id) throws UASException {
		try {
			boolean flag= false;
			ProgramsScheduledBean bean = entityManager.find(ProgramsScheduledBean.class,id);
			if(bean!=null){
				entityManager.remove(bean);
				
			flag = true;
			}
			else{
				flag = false;
			}
			return flag;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public List<ProgramsScheduledBean> viewCommenceTime(ProgramsScheduledBean bean) throws UASException {
		
		

				try {
					TypedQuery<ProgramsScheduledBean> query=entityManager.createQuery("FROM ProgramsScheduledBean where startDate>=? and endDate<=?",ProgramsScheduledBean.class);
					query.setParameter(1, bean.getStartDate());
					query.setParameter(2, bean.getEndDate());
					if(query.getResultList()!=null)
						return query.getResultList();
					else{
						List<ProgramsScheduledBean> list=new ArrayList<ProgramsScheduledBean>();
						return list;
					}
				} catch (Exception e) {
					throw new UASException(e.getMessage());
				}finally {
					if (entityManager != null) {
						entityManager.close();
					}
				}
			
	}
	
	
	@Override
	public List<ProgramsScheduledBean> viewCourse() throws UASException {
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("SELECT d FROM ProgramsScheduledBean d", ProgramsScheduledBean.class);
			return query.getResultList();
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public ApplicationBean addApplicant(ApplicationBean application) throws UASException {
		try {
			entityManager.persist(application);
			entityManager.flush();
			return application;
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public ApplicationBean viewStatus(int id) throws UASException {
		try {
			return entityManager.find(ApplicationBean.class, id);
		} catch (Exception e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public List<ApplicationBean> getAllApplicants(String scheduledProgramID) throws UASException {
		try {
			TypedQuery<ApplicationBean> query=entityManager.createQuery("FROM ApplicationBean where scheduledProgramId=?",ApplicationBean.class);
			int pid=Integer.parseInt(scheduledProgramID);
			query.setParameter(1,pid );
			return query.getResultList();
		} catch (NumberFormatException e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
	}

	@Override
	public String getStatus(String applicantId) throws UASException {
		 try {
			int applicationId=Integer.parseInt(applicantId);
			ApplicationBean bean= entityManager.find(ApplicationBean.class,applicationId);
			return bean.getStatus();
		} catch (NumberFormatException e) {
			throw new UASException(e.getMessage());
		}
		 finally {
				if (entityManager != null) {
					entityManager.close();
				}
			}
	}

	@Override
	public String changeStatus(String status,String applicationId) throws UASException {
		try {
			ApplicationBean bean=new ApplicationBean();
			Query query=entityManager.createQuery("update ApplicationBean set status=? where applicationId=? ");
			query.setParameter(1, status);
			query.setParameter(2, Integer.parseInt(applicationId));
			int count=query.executeUpdate();
			if(count>0){
				bean=entityManager.find(ApplicationBean.class, Integer.parseInt(applicationId));
						return bean.getStatus();
			}
			else
				return null;
		} catch (NumberFormatException e) {
			throw new UASException(e.getMessage());
		}
		finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
		
	}


}


