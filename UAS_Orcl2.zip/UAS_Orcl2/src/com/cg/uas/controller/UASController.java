package com.cg.uas.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.exception.UASException;
import com.cg.uas.service.IUasService;





@Controller
@RequestMapping("/*.obj")
public class UASController {

	@Autowired
	IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}

	@RequestMapping("/welcome")
	public ModelAndView showWelcomePage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 14);
		mv.setViewName("welcome");
		return mv;
	}

	
	//Validate login credentials
	
	@RequestMapping("/login")
	public ModelAndView showloginpage() {
		ModelAndView mv = new ModelAndView();
		LoginBean bean = new LoginBean();
		mv.addObject("isFirst", 1);
		mv.addObject("bean", bean);
		mv.setViewName("welcome");
		return mv;
	}

	@RequestMapping("/loginValidate")
	public ModelAndView loginValidate(
			@ModelAttribute("bean")  LoginBean bean, BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			try {
				LoginBean bean1 = service.login(bean.getUsername(),
						bean.getPassword());
				if (bean1 != null) {
					if (bean1.getPassword().equals(bean.getPassword())) {
						if (bean1.getRole().equals("admin")) {
							mv = new ModelAndView("adminPage");
						} else if (bean1.getRole().equals("mac")) {
							List<ProgramsScheduledBean> list = service.viewCourse();
							if (list.isEmpty()) {
								String msg = "There are no Courses";
								mv.setViewName("macPage");
								mv.addObject("msg", msg);
							} else {
								mv.addObject("isFirst", 4);
								mv.setViewName("macPage");
								mv.addObject("list", list);
							}
						}
					} else {
						String msg = "Incorrect Username or Password";
						mv.addObject("isFirst", 9);
						mv.setViewName("welcome");
						mv.addObject("msg", msg);
					}
				} else {
					String msg = "User Doesn't Exist";
					mv.addObject("isFirst", 9);
					mv.setViewName("welcome");
					mv.addObject("msg", msg);
				}
			} catch (UASException e) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		} else {
			mv = new ModelAndView("welcome", "bean", bean);
			mv.addObject("isFirst", 1);
		}
		return mv;
	}

	@RequestMapping("/programsOffered")
	public ModelAndView offerPrograms() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 4);
		mv.setViewName("adminPage");
		return mv;
	}

	
	//Add to Offered Programs
	
	@RequestMapping("/addProgramsOffered")
	public ModelAndView addOfferedPrograms() {
		ModelAndView mv = new ModelAndView();
		ProgramsOfferedBean bean = new ProgramsOfferedBean();
		mv.addObject("bean", bean);
		mv.setViewName("addPrograms");
		return mv;

	}

	@RequestMapping("/AddToOffered")
	public ModelAndView addPrograms(
			@ModelAttribute("bean")  ProgramsOfferedBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			try {
				ProgramsOfferedBean bean1 = service.addOfferedPrograms(bean);
				if (bean1 != null) {
					mv.addObject("msg", "Added Successfully");
					mv.setViewName("addPrograms");
				} else {
					mv.addObject("msg", "Failed to Add");
					mv.setViewName("addPrograms");
				}

			} catch (Exception e) {
				mv.addObject("msg", "This program is already offered!!");
				mv.setViewName("addPrograms");
			}
		} else {
			mv = new ModelAndView("addPrograms", "bean", bean);
		}
		return mv;
	}

	//To view all the programs Offered
	
	@RequestMapping("/viewAllProgramsOffered")
	public ModelAndView viewAllOfferedPrograms() {
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty())
				mv.addObject("list", list);
			else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("viewAllPrograms");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}
	
	//To Delete the programs offered 

	@RequestMapping("/deleteProgramsOffered")
	public ModelAndView deleteOfferedPrograms() {
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty())
				mv.addObject("list", list);
			else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("deleteProgramsOffered");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("programName") String name) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 6);
		try {
			if (service.deleteProgramsOffered(name)) {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg", "Program details have been removed.");

				mv.setViewName("deleteProgramsOffered");
			} else {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg", "Deletion Failed");
				mv.setViewName("deleteProgramsOffered");
			}
		} catch (Exception e) {
			try {
				List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("isFirst", 7);
				mv.addObject("msg",
						"Cannot Delete this program since it is already scheduled!!");
				mv.setViewName("deleteProgramsOffered");
			} catch (UASException e1) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}
	
	//To Update or Modify the offered programs

	@RequestMapping("/updateProgramsOffered")
	public ModelAndView modifyOfferedPrograms() {
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("modifyProgramsOffered");
			} else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("modifyProgramsOffered");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/modify")
	public ModelAndView modify(@RequestParam("programName") String programName) {
		ModelAndView mv = new ModelAndView();
		try {
			ProgramsOfferedBean bean1 = service.findByName(programName);
			mv.addObject("bean", bean1);
			mv.setViewName("modifyPrograms");
		
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/update")
	public ModelAndView modify(
			@ModelAttribute("bean")  ProgramsOfferedBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		try {
			int count = service.modifyProgram(bean);
			if (count > 0) {
				mv.addObject("msg", "Program Updated Successfully");
				mv.setViewName("modifyPrograms");
			} else {
				mv.addObject("msg", "Updation Failed");
				mv.setViewName("modifyPrograms");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	
	@RequestMapping("/programsScheduled")
	public ModelAndView schedulePrograms() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 8);
		mv.setViewName("adminPage");
		return mv;

	}

	
	//Add the programs to scheduled List
	
	@RequestMapping("/addProgramsScheduled")
	public ModelAndView addscheduledPrograms() {
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("addProgramsScheduled");
				return mv;
			} else {
				mv.addObject("msg", "No Programs are offered currently");
				mv.setViewName("addProgramsScheduled");
			}
			mv.addObject("bean", bean);
			mv.setViewName("addProgramsScheduled");
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;

	}

	@RequestMapping("/AddToScheduled")
	public ModelAndView addProgramsScheduled(
			@RequestParam("programName") String programName) {
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		bean.setProgramName(programName);
		try {
			List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
			mv.addObject("isFirst", 10);
			mv.addObject("list", list);
			mv.addObject("bean", bean);
			mv.setViewName("addProgramsScheduled");
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/AddScheduled")
	public ModelAndView addProgramsScheduled(
			@ModelAttribute("bean")  ProgramsScheduledBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors()) {
				ProgramsScheduledBean bean1 = service
						.addScheduledPrograms(bean);
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv.addObject("list", list);
				if (bean1 != null) {
					mv.addObject("isFirst", 10);
					mv.addObject("flag", 11);
					mv.addObject("msg", "Added Successfully");
					mv.setViewName("addProgramsScheduled");
					return mv;
				}

				else {
					mv.addObject("list", list);
					mv.addObject("msg", "Failed to Add");
					mv.setViewName("addProgramsScheduled");
				}

			}

			else {
				List<ProgramsOfferedBean> list = service
						.viewAllProgramsOffered();
				mv = new ModelAndView("addProgramsScheduled", "bean", bean);
				mv.addObject("isFirst", 10);
				mv.addObject("list", list);
				mv.addObject("flag", 11);
			}
		} catch (Exception e) {
			try {
				List<ProgramsOfferedBean> list = service.viewAllProgramsOffered();
				mv.addObject("list", list);
				mv.addObject("flag", 11);
				mv.addObject("msg", "Please enter a valid program name!");
				mv.setViewName("addProgramsScheduled");
			} catch (UASException e1) {
				String msg = e.getMessage();
				mv.setViewName("error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	
	//Delete Programs from Scheduled list
	
	@RequestMapping("/deleteProgramsScheduled")
	public ModelAndView deleteSchedulePrograms() {
		ModelAndView mv = new ModelAndView();
		try {
			List<ProgramsScheduledBean> list = service.viewAllProgramsScheduled();
			if (!list.isEmpty())
				mv.addObject("list", list);
			else {
				mv.addObject("msg", "No Programs are scheduled currently");
				mv.setViewName("deleteProgramsScheduled");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}

	@RequestMapping("/deleteScheduled")
	public ModelAndView deleteScheduled(@RequestParam("programId") int id) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 11);
		try {
			if (service.deleteProgramsScheduled(id)) {
				mv.addObject("msg",
						"Program is removed from the scheduled list!!");
				mv.setViewName("deleteProgramsScheduled");
			} else {
				mv.addObject("msg", "Deletion Failed");
				mv.setViewName("deleteProgramsScheduled");
			}
		} catch (Exception e) {
			mv.addObject("msg",
					"Cannot Delete this program since there are participants registered for it!!");
			mv.setViewName("deleteProgramsScheduled");
		}
		return mv;
	}

	//To generate reports
	
	@RequestMapping("/generateReports")
	public ModelAndView GenerateReports() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 12);
		mv.setViewName("adminPage");
		return mv;

	}

	@RequestMapping("/viewCommence")
	public ModelAndView viewCommence() {
		ModelAndView mv = new ModelAndView();
		ProgramsScheduledBean bean = new ProgramsScheduledBean();
		mv.addObject("bean", bean);
		mv.setViewName("viewCommence");
		return mv;
	}

	@RequestMapping("/viewCommenceTime")
	public ModelAndView viewCommenceTime(
			@ModelAttribute("bean")  ProgramsScheduledBean bean,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("flag", 2);
		try {
			List<ProgramsScheduledBean> list = service.viewCommenceTime(bean);
			if (!list.isEmpty()) {
				mv.addObject("list", list);
				mv.setViewName("viewCommence");
			} else {
				mv.addObject("flag", 6);
				mv.addObject("msg",
						"No Programs are Scheduled for the given dates!");
				mv.setViewName("viewCommence");
			}
		} catch (UASException e) {
			String msg = e.getMessage();
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	
	
	@RequestMapping("/AboutUs")
	public ModelAndView showabout() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 14);
		mv.setViewName("welcome");
		return mv;
	}

	@RequestMapping("/contactUs")
	public ModelAndView showContact() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("isFirst", 3);
		mv.setViewName("welcome");
		return mv;

	}

}
