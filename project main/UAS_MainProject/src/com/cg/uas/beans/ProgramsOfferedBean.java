package com.cg.uas.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="programs_offered")
public class ProgramsOfferedBean {
	
	@Id
	@Column(name="programName")
	@NotEmpty(message="Field cannot be empty")
	private String programName;
	
	@NotEmpty(message="Field cannot be empty")
	@Column(name="description")
	private String description;
	
	@Column(name="applicant_eligibility")
	@NotEmpty(message="Field cannot be empty")
	private String applicantEligibility;
	
	@Min(2)
	@Column(name="duration")
	private int duration;
	
	@NotEmpty(message="Field cannot be empty")
	@Column(name="degree_certificate_offered")
	private String degreeCertificate;
	
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicantEligibility() {
		return applicantEligibility;
	}
	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getDegreeCertificate() {
		return degreeCertificate;
	}
	public void setDegreeCertificate(String degreeCertificate) {
		this.degreeCertificate = degreeCertificate;
	}
	
	
}
