package com.cg.uas.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.ApplicationBean;
import com.cg.uas.beans.ProgramsScheduledBean;
import com.cg.uas.exception.UASException;
import com.cg.uas.service.IUasService;

@Controller
@RequestMapping("/*.mac")
public class MACController {

	@Autowired
	private IUasService service;

	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}

	@RequestMapping("/programList")
	public ModelAndView viewPrograms() throws UASException {
		ModelAndView mv = new ModelAndView();
		List<ProgramsScheduledBean> list = service.viewCourse();
		if (list.isEmpty()) {
			String msg = "There are no Courses";
			mv.setViewName("macPage");
			mv.addObject("msg", msg);
		} else {
			mv.addObject("isFirst", 4);
			mv.setViewName("macPage");
			mv.addObject("list", list);
		}
		return mv;
	}

	@RequestMapping("/view")
	public ModelAndView viewApplicantsByProgram(
			@RequestParam("scheduledProgramId") String scheduledProgramId) throws UASException {
		ModelAndView mv = new ModelAndView();
		List<ApplicationBean> list = service
				.getAllApplicants(scheduledProgramId);
		if (!list.isEmpty()) {
			mv.addObject("list", list);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 1);
			mv.setViewName("viewApplicants");
		} else {
			mv.addObject("flag", 2);
			mv.addObject("msg", "No Applicant is Registered for this Program");
			mv.setViewName("viewApplicants");
		}

		return mv;
	}

	@RequestMapping("/status")
	public ModelAndView viewStatus(
			@RequestParam("applicationId") String applicantId,
			@RequestParam("scheduledProgramId") String scheduledProgramId) throws UASException {
		ModelAndView mv = new ModelAndView();
		String status = service.getStatus(applicantId);
		mv.addObject("status", status);
		if (status.equals("Waiting")) {
			mv.addObject("flag", 6);
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("accepted", "accepted");
			mv.addObject("rejected", "rejected");
			mv.setViewName("changeStatus");
		} else {
			mv.addObject("applicationId", applicantId);
			mv.addObject("scheduledProgramId", scheduledProgramId);
			mv.addObject("flag", 5);
			mv.addObject("msg", "Status Cannot be Changed");
			mv.setViewName("changeStatus");
		}

		return mv;
	}

	@RequestMapping("/changeStatus")
	public ModelAndView changeStatus(@RequestParam("status") String status,
			@RequestParam("applicationId") String applicantId,
			@RequestParam("scheduledProgramId") String scheduledProgramId) throws UASException {
		ModelAndView mv = new ModelAndView();

		String newStatus = service.changeStatus(status, applicantId);
		mv.addObject("applicationId", applicantId);
		mv.addObject("scheduledProgramId", scheduledProgramId);
		if (newStatus.equals("rejected")) {
			mv.addObject("flag", 5);
			mv.addObject("msg", "Application has been Rejected");
			mv.setViewName("changeStatus");
		} else {
			mv.addObject("flag", 5);
			mv.addObject("msg", "Application has been Accepted");
			mv.setViewName("changeStatus");
		}
		return mv;
	}

}
