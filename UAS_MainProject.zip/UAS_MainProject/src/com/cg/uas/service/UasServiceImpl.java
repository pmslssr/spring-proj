package com.cg.uas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.dao.IUasDao;


@Service
@Transactional
public class UasServiceImpl implements IUasService {

	@Autowired
	IUasDao dao;
	
	
	
	public IUasDao getDao() {
		return dao;
	}



	public void setDao(IUasDao dao) {
		this.dao = dao;
	}



	@Override
	public LoginBean login(String username, String password) {
		
		return dao.login(username, password);
				
	}



	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) {
		return dao.addOfferedPrograms(bean);
	}



	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {
		return dao.viewAllProgramsOffered();
	}

}
