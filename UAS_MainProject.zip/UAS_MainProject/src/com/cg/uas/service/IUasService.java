package com.cg.uas.service;

import java.util.List;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;

public interface IUasService {
	public LoginBean login(String username, String password) ;
	
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean);
	
	public List<ProgramsOfferedBean> viewAllProgramsOffered();

}
