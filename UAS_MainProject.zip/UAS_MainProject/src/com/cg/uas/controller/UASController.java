package com.cg.uas.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;
import com.cg.uas.service.IUasService;

@Controller
public class UASController {
	
	@Autowired
	IUasService service;
	
	
	
	public IUasService getService() {
		return service;
	}

	public void setService(IUasService service) {
		this.service = service;
	}

	
	@RequestMapping("/welcome")
	public ModelAndView showWelcomePage() {
		ModelAndView mv=new ModelAndView();
	
		mv.setViewName("welcome");

		
		
	return mv;
		
	}
	
	
	@RequestMapping("/login")
	public ModelAndView showloginpage() {
		ModelAndView mv=new ModelAndView();
		LoginBean bean=new LoginBean();
		mv.addObject("isFirst",1);
	mv.addObject("bean", bean);
		mv.setViewName("welcome");
		return mv;
		
	}
	
	@RequestMapping("/loginValidate")
	public ModelAndView loginValidate(	@ModelAttribute("bean") @Valid LoginBean bean,
			BindingResult result) {
		
		ModelAndView mv =new ModelAndView();
		if (!result.hasErrors()) {
		LoginBean bean1=service.login(bean.getUsername(), bean.getPassword());
		if(bean1!=null){
			if(bean1.getPassword().equals(bean.getPassword())){
		if(bean1.getRole().equals("admin"))
		{
				mv = new ModelAndView("adminPage");
		}
		else if(bean1.getRole().equals("mac")){
				mv = new ModelAndView("macPage");
		}
		}
		else{
			String msg = "Incorrect Username or Password";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		}
		else{
			String msg = "User Doesn't Exist";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}
		}
		else{
			mv = new ModelAndView("login", "bean", bean);
		}
		
		return mv;
		
		
	}
	@RequestMapping("/programsOffered")
	public ModelAndView offerPrograms() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("isFirst",4);
		mv.setViewName("adminPage");
	return mv;
		
	}
	
	@RequestMapping("/addProgramsOffered")
	public ModelAndView addOfferedPrograms() {
		ModelAndView mv=new ModelAndView();
		ProgramsOfferedBean bean=new ProgramsOfferedBean();
		//mv.addObject("isFirst",4);
		mv.addObject("bean", bean);
		mv.setViewName("addPrograms");
	return mv;
		
	}
	
	@RequestMapping("/AddToOffered")
	public ModelAndView addPrograms(@ModelAttribute("bean") @Valid ProgramsOfferedBean bean,
			BindingResult result) {
		ModelAndView mv=new ModelAndView();
		ProgramsOfferedBean bean1=service.addOfferedPrograms(bean);
		if(bean1!=null)
			mv.addObject("msg", "Added Successfully");
		else
			mv.addObject("msg", "Failed to Add");
		
		mv.setViewName("addPrograms");
	return mv;
		
	}
	
	@RequestMapping("/viewAllProgramsOffered")
	public ModelAndView viewAllOfferedPrograms() {
		ModelAndView mv=new ModelAndView();
		ProgramsOfferedBean bean=new ProgramsOfferedBean();
		List<ProgramsOfferedBean> list=service.viewAllProgramsOffered();
		if(!list.isEmpty())
			mv.addObject("list", list);
		else
			mv.addObject("msg", "No Programs are offered currently");
		mv.setViewName("viewAllPrograms");
	return mv;
		
	}
	
	@RequestMapping("/deleteProgramsOffered")
	public ModelAndView deleteOfferedPrograms() {
		ModelAndView mv=new ModelAndView();
		ProgramsOfferedBean bean=new ProgramsOfferedBean();
		List<ProgramsOfferedBean> list=service.viewAllProgramsOffered();
		if(!list.isEmpty())
			mv.addObject("list", list);
		else
			mv.addObject("msg", "No Programs are offered currently");
		mv.setViewName("deleteProgramsOffered");
	return mv;
		
	}
	@RequestMapping("/delete")
	public ModelAndView delete(@ModelAttribute("bean") @Valid ProgramsOfferedBean bean,
			BindingResult result){
		ModelAndView mv=new ModelAndView();
				return null;
		
	}

	@RequestMapping("/AboutUs")
	public ModelAndView showabout() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("isFirst",2);
		mv.setViewName("welcome");
	return mv;
		
	}
	
	@RequestMapping("/contactUs")
	public ModelAndView showContact() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("isFirst",3);
		mv.setViewName("welcome");
	return mv;
		
	}
}
