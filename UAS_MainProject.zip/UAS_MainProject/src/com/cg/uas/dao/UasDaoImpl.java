package com.cg.uas.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;


@Repository
@Transactional
public class UasDaoImpl implements IUasDao {


	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public LoginBean login(String username, String password) {
		LoginBean bean = entityManager.find(LoginBean.class,username);
		
		return bean;
	}

	@Override
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean) {
		entityManager.persist(bean);
		ProgramsOfferedBean bean1=entityManager.find(ProgramsOfferedBean.class, bean.getProgramName());
		entityManager.flush();
		return bean1;
	}

	@Override
	public List<ProgramsOfferedBean> viewAllProgramsOffered() {
		TypedQuery<ProgramsOfferedBean> query=entityManager.createQuery("FROM ProgramsOfferedBean",ProgramsOfferedBean.class);
		if(query.getResultList()!=null)
			return query.getResultList();
		else{
			List<ProgramsOfferedBean> list=new ArrayList<ProgramsOfferedBean>();
			return list;
		}
	}

	}


