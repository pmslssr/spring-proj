package com.cg.uas.dao;

import java.util.List;

import com.cg.uas.beans.LoginBean;
import com.cg.uas.beans.ProgramsOfferedBean;

public interface IUasDao {

	public LoginBean login(String username, String password);
	
	public ProgramsOfferedBean addOfferedPrograms(ProgramsOfferedBean bean);
	
	public List<ProgramsOfferedBean> viewAllProgramsOffered();
}
