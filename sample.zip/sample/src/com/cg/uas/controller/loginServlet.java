package com.cg.uas.controller;



import java.io.FileReader;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public loginServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		  
	        
		
		try {
			

			
			JSONParser parser = new JSONParser();
			

	            Object obj = parser.parse(new FileReader("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\LoginJSON.json"));

	            JSONObject jsonObject = (JSONObject) obj;
	           
	            String uname = (String) jsonObject.get("username");
	            System.out.println(uname);

	            String pwd = (String) jsonObject.get("password");
	            System.out.println(pwd);
	            
	            String username = request.getParameter("username");
		        String password = request.getParameter("password");
		         
		        
		        System.out.println(username);
		        System.out.println(password);
	            
		        if(uname.equals(username) && pwd.equals(password))
		        {
		        	System.out.println("login success");
		        	response.sendRedirect("adminPage.jsp");
		        }
		        else
		        {
		        	System.out.println("Wrong login");
		        }
		        
	          
	            
		} catch (Exception e) {
			e.printStackTrace();
		
	}

	}}
