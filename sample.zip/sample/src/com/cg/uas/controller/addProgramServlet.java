package com.cg.uas.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.script.*;

import jdk.nashorn.internal.parser.JSONParser;

import com.sun.corba.se.impl.orbutil.ObjectWriter;

public class addProgramServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public addProgramServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String programName = request.getParameter("programName");
	        String description = request.getParameter("description");
	        String applicantEligibility = request.getParameter("applicantEligibility");
	        String duration = request.getParameter("duration");
	        String degreeCertificate = request.getParameter("degreeCertificate");


	        	File f = new File("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json");

        		if(f.length() == 0)
        		{
        		

					try {
						JSONObject valuesObject = new JSONObject();
						JSONArray list = new JSONArray();

						valuesObject = new JSONObject();
						valuesObject.put("programName",programName);
						valuesObject.put("description", description);
						valuesObject.put("applicantEligibility", applicantEligibility);
						valuesObject.put("duration", duration);
						valuesObject.put("degreeCertificate", degreeCertificate);
						
						list.put(valuesObject);
						try(FileWriter file = new FileWriter("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json"))
						{
							file.write(valuesObject.toString());
							file.flush();
							file.close();
							
						}
						catch(IOException e)
						{
							e.printStackTrace();
						}
						
						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
        		}
        		else
        		{
	        
	        
	        BufferedReader br = new BufferedReader(new FileReader("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json"));
	     
	            try {
					StringBuilder sb = new StringBuilder();
					String line = br.readLine();

					while (line != null) {
					    sb.append(line);
					    sb.append("\n");
					    line = br.readLine();
					}
       
					
					
					String jsonDataString= sb.toString();
					String s1 = jsonDataString;
				
					JSONObject mainObject = new JSONObject(jsonDataString);
					JSONObject valuesObject = new JSONObject();
					JSONArray list = new JSONArray();
	
					valuesObject = new JSONObject();
					valuesObject.put("programName",programName);
					valuesObject.put("description", description);
					valuesObject.put("applicantEligibility", applicantEligibility);
					valuesObject.put("duration", duration);
					valuesObject.put("degreeCertificate", degreeCertificate);
					
					list.put(valuesObject);
				//	mainObject.accumulate("programs", list);
					String s2 = mainObject.toString();
				//	System.out.println(s2);
					String s3=new String("");
					s1=s1.substring(s1.indexOf("[")+1, s1.lastIndexOf("]"));
					s2=s2.substring(s2.indexOf("[")+1, s2.lastIndexOf("]"));
					s3="["+s1+","+s2+"]";
					System.out.println(s3);
					
			        
					try(FileWriter file = new FileWriter("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json"))
					{
						file.write(s3);
						file.flush();
						file.close();
						
					}
					catch(IOException e)
					{
						e.printStackTrace();
					}
					
					
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	        
	        
        		}
	        
	        
	        
	        
	       
	       
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        /*      try {

				Program d = new Program();
				ObjectMapper mapper = new ObjectMapper();
				Map<String, Object> dataMap = mapper.readValue(new File("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json"), Map.class);
			
				
				System.out.println(dataMap);
				
				System.out.println(dataMap.get("name"));
				System.out.println(dataMap.get("adress"));
				System.out.println(dataMap.get("age"));
				
			} catch (JsonParseException e) {
				e.printStackTrace();
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}


	
	*/
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        /*
	        
	 
        
JSONObject allPrograms=new JSONObject();
try {
JSONArray prgmArray=new JSONArray();
JSONObject prgmObj= new JSONObject();



FileWriter file = new FileWriter("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json",true);

	prgmObj = new JSONObject();
	prgmObj.put("programName",programName);
	prgmObj.put("description", description);
	prgmObj.put("applicantEligibility", applicantEligibility);
	prgmObj.put("duration", duration);
	prgmObj.put("degreeCertificate", degreeCertificate);
	prgmArray.put(prgmObj);
	 
	allPrograms.put("Programs", prgmArray);
	
	

	
} catch (JSONException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
        
        
try(FileWriter file = new FileWriter("D:\\praneeth\\java EE workspace\\sample\\WebContent\\JSON\\ProgramsOffered\\programsOffered.json", true))
{
	file.append(allPrograms.toString());
	file.flush();
	file.close();
	
}
catch(IOException e)
{
	e.printStackTrace();
}
*/
        
	}	

class Program
{
	
	String programName;
	String description;
	String applicantEligibility;
    String duration;
    String degreeCertificate;
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicantEligibility() {
		return applicantEligibility;
	}
	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getDegreeCertificate() {
		return degreeCertificate;
	}
	public void setDegreeCertificate(String degreeCertificate) {
		this.degreeCertificate = degreeCertificate;
	}
    
    
    
}

}















